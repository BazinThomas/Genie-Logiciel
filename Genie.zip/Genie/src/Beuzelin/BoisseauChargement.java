package Beuzelin;

import java.util.logging.Level;
import java.util.logging.Logger;

public class BoisseauChargement extends Conteneur 
{
    
    //Constructeur
    public BoisseauChargement(){	
        super();
    }
    
    public BoisseauChargement(InfoCereales info, int pm){
        super(info, pm);
    }
}