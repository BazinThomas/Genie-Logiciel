package Beuzelin;

import java.util.logging.Level;
import java.util.logging.Logger;

public class Fosse extends Conteneur 
{
    
    //Constructeur
    public Fosse(){	
        super();
    }
    
    public Fosse(InfoCereales info, int pm){
        super(info, pm);
    }
}
