/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Beuzelin;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author dortp
 */
public class CerealeTest {
    
    public CerealeTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of Nettoyage method, of class Cereale.
     */
    @Test
    public void testNettoyage() {
        System.out.println("Nettoyage");
        Cereale instance = null;
        instance.Nettoyage();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getNoLot method, of class Cereale.
     */
    @Test
    public void testGetNoLot() {
        System.out.println("getNoLot");
        Cereale instance = null;
        double expResult = 0.0;
        double result = instance.getNoLot();
        assertEquals(expResult, result, 0.0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setNoLot method, of class Cereale.
     */
    @Test
    public void testSetNoLot() {
        System.out.println("setNoLot");
        double Nolot = 0.0;
        Cereale instance = null;
        instance.setNoLot(Nolot);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getType method, of class Cereale.
     */
    @Test
    public void testGetType() {
        System.out.println("getType");
        Cereale instance = null;
        String expResult = "";
        String result = instance.getType();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setType method, of class Cereale.
     */
    @Test
    public void testSetType() {
        System.out.println("setType");
        String type = "";
        Cereale instance = null;
        instance.setType(type);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getVolume method, of class Cereale.
     */
    @Test
    public void testGetVolume() {
        System.out.println("getVolume");
        Cereale instance = null;
        int expResult = 0;
        int result = instance.getVolume();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setVolume method, of class Cereale.
     */
    @Test
    public void testSetVolume() {
        System.out.println("setVolume");
        int volume = 0;
        Cereale instance = null;
        instance.setVolume(volume);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getQualite method, of class Cereale.
     */
    @Test
    public void testGetQualite() {
        System.out.println("getQualite");
        Cereale instance = null;
        String expResult = "";
        String result = instance.getQualite();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setQualite method, of class Cereale.
     */
    @Test
    public void testSetQualite() {
        System.out.println("setQualite");
        String qualite = "";
        Cereale instance = null;
        instance.setQualite(qualite);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getTauxHumidite method, of class Cereale.
     */
    @Test
    public void testGetTauxHumidite() {
        System.out.println("getTauxHumidite");
        Cereale instance = null;
        float expResult = 0.0F;
        float result = instance.getTauxHumidite();
        assertEquals(expResult, result, 0.0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setTauxHumidite method, of class Cereale.
     */
    @Test
    public void testSetTauxHumidite() {
        System.out.println("setTauxHumidite");
        float TauxHumidite = 0.0F;
        Cereale instance = null;
        instance.setTauxHumidite(TauxHumidite);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getTemperature method, of class Cereale.
     */
    @Test
    public void testGetTemperature() {
        System.out.println("getTemperature");
        Cereale instance = null;
        float expResult = 0.0F;
        float result = instance.getTemperature();
        assertEquals(expResult, result, 0.0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setTemperature method, of class Cereale.
     */
    @Test
    public void testSetTemperature() {
        System.out.println("setTemperature");
        float temperature = 0.0F;
        Cereale instance = null;
        instance.setTemperature(temperature);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of toString method, of class Cereale.
     */
    @Test
    public void testToString() {
        System.out.println("toString");
        Cereale instance = null;
        String expResult = "";
        String result = instance.toString();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
