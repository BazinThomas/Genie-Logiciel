/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Beuzelin;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author dortp
 */
public class SondeTest {
    
    public SondeTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of transmission method, of class Sonde.
     */
    @Test
    public void testTransmission() {
        System.out.println("transmission");
        Sonde instance = null;
        instance.transmission();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of RecupTemperature method, of class Sonde.
     */
    @Test
    public void testRecupTemperature() {
        System.out.println("RecupTemperature");
        Sonde instance = null;
        int expResult = 0;
        int result = instance.RecupTemperature();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getTemperature method, of class Sonde.
     */
    @Test
    public void testGetTemperature() {
        System.out.println("getTemperature");
        Sonde instance = null;
        int expResult = 0;
        int result = instance.getTemperature();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setTemperature method, of class Sonde.
     */
    @Test
    public void testSetTemperature() {
        System.out.println("setTemperature");
        int temperature = 0;
        Sonde instance = null;
        instance.setTemperature(temperature);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of toString method, of class Sonde.
     */
    @Test
    public void testToString() {
        System.out.println("toString");
        Sonde instance = null;
        String expResult = "";
        String result = instance.toString();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
