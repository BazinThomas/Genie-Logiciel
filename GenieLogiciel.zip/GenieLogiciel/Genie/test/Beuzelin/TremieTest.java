/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Beuzelin;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author dortp
 */
public class TremieTest {
    
    public TremieTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of trie method, of class Tremie.
     */
    @Test
    public void testTrie() {
        System.out.println("trie");
        double NoLot = 0.0;
        Tremie instance = null;
        Cereale expResult = null;
        Cereale result = instance.trie(NoLot);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getPlein method, of class Tremie.
     */
    @Test
    public void testGetPlein() {
        System.out.println("getPlein");
        Tremie instance = null;
        boolean expResult = false;
        boolean result = instance.getPlein();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setPlein method, of class Tremie.
     */
    @Test
    public void testSetPlein() {
        System.out.println("setPlein");
        boolean plein = false;
        Tremie instance = null;
        instance.setPlein(plein);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
