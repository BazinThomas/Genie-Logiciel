/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Beuzelin;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author dortp
 */
public class ConteneurTest {
    
    public ConteneurTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of remplir method, of class Conteneur.
     */
    @Test
    public void testRemplir() {
        System.out.println("remplir");
        Conteneur instance = new Conteneur();
        instance.remplir();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of vider method, of class Conteneur.
     */
    @Test
    public void testVider() {
        System.out.println("vider");
        Conteneur instance = new Conteneur();
        instance.vider();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getInfo method, of class Conteneur.
     */
    @Test
    public void testGetInfo() {
        System.out.println("getInfo");
        Conteneur instance = new Conteneur();
        InfoCereales expResult = null;
        InfoCereales result = instance.getInfo();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setInfo method, of class Conteneur.
     */
    @Test
    public void testSetInfo() {
        System.out.println("setInfo");
        InfoCereales info = null;
        Conteneur instance = new Conteneur();
        instance.setInfo(info);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getPoidsMax method, of class Conteneur.
     */
    @Test
    public void testGetPoidsMax() {
        System.out.println("getPoidsMax");
        Conteneur instance = new Conteneur();
        int expResult = 0;
        int result = instance.getPoidsMax();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setPoidsMax method, of class Conteneur.
     */
    @Test
    public void testSetPoidsMax() {
        System.out.println("setPoidsMax");
        int poidsMax = 0;
        Conteneur instance = new Conteneur();
        instance.setPoidsMax(poidsMax);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
