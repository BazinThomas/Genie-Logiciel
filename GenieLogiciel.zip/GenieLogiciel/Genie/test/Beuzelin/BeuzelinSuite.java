/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Beuzelin;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

/**
 *
 * @author dortp
 */
@RunWith(Suite.class)
@Suite.SuiteClasses({Beuzelin.MainVueTest.class, Beuzelin.CamionTest.class, Beuzelin.SondeTest.class, Beuzelin.FosseTest.class, Beuzelin.SiloTest.class, Beuzelin.VueInfoTest.class, Beuzelin.CerealeTest.class, Beuzelin.AlarmeTest.class, Beuzelin.InfoCerealesTest.class, Beuzelin.ControleurTest.class, Beuzelin.VueReceptionTest.class, Beuzelin.VueExpeditionTest.class, Beuzelin.VueSiloTest.class, Beuzelin.BoisseauChargementTest.class, Beuzelin.CelluleTest.class, Beuzelin.ConteneurTest.class, Beuzelin.TremieTest.class})
public class BeuzelinSuite {

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }
    
}
