/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Beuzelin;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author dortp
 */
public class CamionTest {
    
    public CamionTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of Depose method, of class Camion.
     */
    @Test
    public void testDepose() {
        System.out.println("Depose");
        Camion instance = null;
        instance.Depose();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getId method, of class Camion.
     */
    @Test
    public void testGetId() {
        System.out.println("getId");
        Camion instance = null;
        int expResult = 0;
        int result = instance.getId();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setId method, of class Camion.
     */
    @Test
    public void testSetId() {
        System.out.println("setId");
        int id = 0;
        Camion instance = null;
        instance.setId(id);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getTypeContenu method, of class Camion.
     */
    @Test
    public void testGetTypeContenu() {
        System.out.println("getTypeContenu");
        Camion instance = null;
        String expResult = "";
        String result = instance.getTypeContenu();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setTypeContenu method, of class Camion.
     */
    @Test
    public void testSetTypeContenu() {
        System.out.println("setTypeContenu");
        String TypeContenu = "";
        Camion instance = null;
        instance.setTypeContenu(TypeContenu);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getTypeTransport method, of class Camion.
     */
    @Test
    public void testGetTypeTransport() {
        System.out.println("getTypeTransport");
        Camion instance = null;
        String expResult = "";
        String result = instance.getTypeTransport();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setTypeTransport method, of class Camion.
     */
    @Test
    public void testSetTypeTransport() {
        System.out.println("setTypeTransport");
        String TypeTransport = "";
        Camion instance = null;
        instance.setTypeTransport(TypeTransport);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getVolumeContenu method, of class Camion.
     */
    @Test
    public void testGetVolumeContenu() {
        System.out.println("getVolumeContenu");
        Camion instance = null;
        int expResult = 0;
        int result = instance.getVolumeContenu();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setVolumeContenu method, of class Camion.
     */
    @Test
    public void testSetVolumeContenu() {
        System.out.println("setVolumeContenu");
        int VolumeContenu = 0;
        Camion instance = null;
        instance.setVolumeContenu(VolumeContenu);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getVide method, of class Camion.
     */
    @Test
    public void testGetVide() {
        System.out.println("getVide");
        Camion instance = null;
        boolean expResult = false;
        boolean result = instance.getVide();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setVide method, of class Camion.
     */
    @Test
    public void testSetVide() {
        System.out.println("setVide");
        boolean Vide = false;
        Camion instance = null;
        instance.setVide(Vide);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
