/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Beuzelin;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author dortp
 */
public class AlarmeTest {
    
    public AlarmeTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of stopProcessus method, of class Alarme.
     */
    @Test
    public void testStopProcessus() {
        System.out.println("stopProcessus");
        Alarme instance = null;
        instance.stopProcessus();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of stopAlarme method, of class Alarme.
     */
    @Test
    public void testStopAlarme() {
        System.out.println("stopAlarme");
        Alarme instance = null;
        instance.stopAlarme();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getCause method, of class Alarme.
     */
    @Test
    public void testGetCause() {
        System.out.println("getCause");
        Alarme instance = null;
        String expResult = "";
        String result = instance.getCause();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setCause method, of class Alarme.
     */
    @Test
    public void testSetCause() {
        System.out.println("setCause");
        String cause = "";
        Alarme instance = null;
        instance.setCause(cause);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of isActive method, of class Alarme.
     */
    @Test
    public void testIsActive() {
        System.out.println("isActive");
        Alarme instance = null;
        boolean expResult = false;
        boolean result = instance.isActive();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setActive method, of class Alarme.
     */
    @Test
    public void testSetActive() {
        System.out.println("setActive");
        boolean active = false;
        Alarme instance = null;
        instance.setActive(active);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
