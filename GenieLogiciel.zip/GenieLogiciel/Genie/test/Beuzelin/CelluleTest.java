/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Beuzelin;

import java.util.Date;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author dortp
 */
public class CelluleTest {
    
    public CelluleTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getNettoyage method, of class Cellule.
     */
    @Test
    public void testGetNettoyage() {
        System.out.println("getNettoyage");
        Cellule instance = new Cellule();
        Date expResult = null;
        Date result = instance.getNettoyage();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setNettoyage method, of class Cellule.
     */
    @Test
    public void testSetNettoyage() {
        System.out.println("setNettoyage");
        Date nettoyage = null;
        Cellule instance = new Cellule();
        instance.setNettoyage(nettoyage);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getVentilation method, of class Cellule.
     */
    @Test
    public void testGetVentilation() {
        System.out.println("getVentilation");
        Cellule instance = new Cellule();
        Date expResult = null;
        Date result = instance.getVentilation();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setVentilation method, of class Cellule.
     */
    @Test
    public void testSetVentilation() {
        System.out.println("setVentilation");
        Date ventilation = null;
        Cellule instance = new Cellule();
        instance.setVentilation(ventilation);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getTraitement method, of class Cellule.
     */
    @Test
    public void testGetTraitement() {
        System.out.println("getTraitement");
        Cellule instance = new Cellule();
        Date expResult = null;
        Date result = instance.getTraitement();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setTraitement method, of class Cellule.
     */
    @Test
    public void testSetTraitement() {
        System.out.println("setTraitement");
        Date traitement = null;
        Cellule instance = new Cellule();
        instance.setTraitement(traitement);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getNum method, of class Cellule.
     */
    @Test
    public void testGetNum() {
        System.out.println("getNum");
        Cellule instance = new Cellule();
        int expResult = 0;
        int result = instance.getNum();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setNum method, of class Cellule.
     */
    @Test
    public void testSetNum() {
        System.out.println("setNum");
        int num = 0;
        Cellule instance = new Cellule();
        instance.setNum(num);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getSonde method, of class Cellule.
     */
    @Test
    public void testGetSonde() {
        System.out.println("getSonde");
        Cellule instance = new Cellule();
        Sonde expResult = null;
        Sonde result = instance.getSonde();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setSonde method, of class Cellule.
     */
    @Test
    public void testSetSonde() {
        System.out.println("setSonde");
        Sonde sonde = null;
        Cellule instance = new Cellule();
        instance.setSonde(sonde);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
