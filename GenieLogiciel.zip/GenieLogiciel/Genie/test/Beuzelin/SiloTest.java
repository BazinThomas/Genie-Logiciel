/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Beuzelin;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author dortp
 */
public class SiloTest {
    
    public SiloTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of init method, of class Silo.
     */
    @Test
    public void testInit() {
        System.out.println("init");
        Silo instance = new Silo();
        instance.init();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of Nettoyage method, of class Silo.
     */
    @Test
    public void testNettoyage() {
        System.out.println("Nettoyage");
        Silo instance = new Silo();
        instance.Nettoyage();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of Ventilation method, of class Silo.
     */
    @Test
    public void testVentilation() {
        System.out.println("Ventilation");
        Silo instance = new Silo();
        instance.Ventilation();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getNbCellule method, of class Silo.
     */
    @Test
    public void testGetNbCellule() {
        System.out.println("getNbCellule");
        Silo instance = new Silo();
        int expResult = 0;
        int result = instance.getNbCellule();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getCellule method, of class Silo.
     */
    @Test
    public void testGetCellule() {
        System.out.println("getCellule");
        int v = 0;
        Silo instance = new Silo();
        Cellule expResult = null;
        Cellule result = instance.getCellule(v);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getInfo method, of class Silo.
     */
    @Test
    public void testGetInfo() {
        System.out.println("getInfo");
        int v = 0;
        Silo instance = new Silo();
        InfoCereales expResult = null;
        InfoCereales result = instance.getInfo(v);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getInfoNum method, of class Silo.
     */
    @Test
    public void testGetInfoNum() {
        System.out.println("getInfoNum");
        int v = 0;
        Silo instance = new Silo();
        boolean expResult = false;
        boolean result = instance.getInfoNum(v);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
