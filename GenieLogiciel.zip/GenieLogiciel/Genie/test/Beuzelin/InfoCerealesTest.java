/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Beuzelin;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author dortp
 */
public class InfoCerealesTest {
    
    public InfoCerealesTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getCategorie method, of class InfoCereales.
     */
    @Test
    public void testGetCategorie() {
        System.out.println("getCategorie");
        InfoCereales instance = new InfoCereales();
        String expResult = "";
        String result = instance.getCategorie();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setCategorie method, of class InfoCereales.
     */
    @Test
    public void testSetCategorie() {
        System.out.println("setCategorie");
        String categorie = "";
        InfoCereales instance = new InfoCereales();
        instance.setCategorie(categorie);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getPoids method, of class InfoCereales.
     */
    @Test
    public void testGetPoids() {
        System.out.println("getPoids");
        InfoCereales instance = new InfoCereales();
        int expResult = 0;
        int result = instance.getPoids();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setPoids method, of class InfoCereales.
     */
    @Test
    public void testSetPoids() {
        System.out.println("setPoids");
        int poids = 0;
        InfoCereales instance = new InfoCereales();
        instance.setPoids(poids);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getQualite method, of class InfoCereales.
     */
    @Test
    public void testGetQualite() {
        System.out.println("getQualite");
        InfoCereales instance = new InfoCereales();
        String expResult = "";
        String result = instance.getQualite();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setQualite method, of class InfoCereales.
     */
    @Test
    public void testSetQualite() {
        System.out.println("setQualite");
        String qualite = "";
        InfoCereales instance = new InfoCereales();
        instance.setQualite(qualite);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getNumLot method, of class InfoCereales.
     */
    @Test
    public void testGetNumLot() {
        System.out.println("getNumLot");
        InfoCereales instance = new InfoCereales();
        int expResult = 0;
        int result = instance.getNumLot();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setNumLot method, of class InfoCereales.
     */
    @Test
    public void testSetNumLot() {
        System.out.println("setNumLot");
        int numLot = 0;
        InfoCereales instance = new InfoCereales();
        instance.setNumLot(numLot);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getVolume method, of class InfoCereales.
     */
    @Test
    public void testGetVolume() {
        System.out.println("getVolume");
        InfoCereales instance = new InfoCereales();
        int expResult = 0;
        int result = instance.getVolume();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setVolume method, of class InfoCereales.
     */
    @Test
    public void testSetVolume() {
        System.out.println("setVolume");
        int volume = 0;
        InfoCereales instance = new InfoCereales();
        instance.setVolume(volume);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of toString method, of class InfoCereales.
     */
    @Test
    public void testToString() {
        System.out.println("toString");
        InfoCereales instance = new InfoCereales();
        String expResult = "";
        String result = instance.toString();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
